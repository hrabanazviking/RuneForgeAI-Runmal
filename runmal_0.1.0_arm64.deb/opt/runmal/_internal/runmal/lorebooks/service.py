"""Lorebook + lore entry CRUD, ownership-scoped (S201).

Entries always resolve through their parent book: an entry is addressable
only via a book the caller owns. Keys are stored as JSON text and validated
as string lists at the boundary.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime

from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from runmal.db.models import Lorebook, LoreEntry
from runmal.lorebooks.groups import (
    check_group_weight,
    check_inclusion_group,
    normalise_group_weight,
    normalise_inclusion_group,
)
from runmal.lorebooks.logic import check_selective_logic, normalise_selective_logic
from runmal.lorebooks.states import activation_kind_for
from runmal.lorebooks.rng import check_probability, normalise_probability
from runmal.lorebooks.windows import (
    check_scan_depth,
    check_scan_external_context,
    check_scan_mode,
    normalise_scan_external_context,
    normalise_scan_mode,
)

# Position vocabulary is owned by runmal.lorebooks.placement (P-038),
# which admits at_depth alongside before_char / after_char; the name
# stays importable here for existing callers.
from runmal.lorebooks.placement import (
    VALID_POSITIONS,  # noqa: E402,F401
    check_depth,
    check_position,
    check_role,
    normalise_depth,
    normalise_role,
)
from runmal.lorebooks.rng import check_probability, normalise_probability
from runmal.lorebooks.states import activation_kind_for


def _now() -> datetime:
    return datetime.now(UTC)


def _encode_keys(keys: list[str] | None) -> str:
    if keys is None:
        return "[]"
    if not isinstance(keys, list) or any(not isinstance(k, str) for k in keys):
        raise ValueError("keys must be a list of strings")
    return json.dumps(keys)


def _decode_keys(raw: str) -> list[str]:
    try:
        decoded = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"stored keys are not valid JSON: {exc}") from exc
    if not isinstance(decoded, list):
        raise ValueError("stored keys are not a list")
    return [str(k) for k in decoded]


def _check_prompts(name: str, value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{name} must be an integer >= 0")
    return value


# Backwards-compatible alias: transfer.py calls service._check_position;
# the strict checker itself lives in placement (P-038).
_check_position = check_position


def lorebook_to_dict(book: Lorebook, entry_count: int = 0) -> dict:
    return {
        "id": book.id,
        "name": book.name,
        "description": book.description,
        "scan_depth": book.scan_depth,
        "token_budget": book.token_budget,
        "scan_mode": normalise_scan_mode(getattr(book, "scan_mode", None)),
        "scan_external_context": normalise_scan_external_context(
            getattr(book, "scan_external_context", None)
        ),
        "created_at": book.created_at.isoformat(),
        "entry_count": entry_count,
    }


def entry_to_dict(entry: LoreEntry) -> dict:
    return {
        "id": entry.id,
        "lorebook_id": entry.lorebook_id,
        "name": entry.name,
        "content": entry.content,
        "keys": _decode_keys(entry.keys_json),
        "secondary_keys": _decode_keys(entry.secondary_keys_json),
        "selective_logic": normalise_selective_logic(getattr(entry, "selective_logic", None)),
        "inclusion_group": normalise_inclusion_group(getattr(entry, "inclusion_group", None)),
        "group_weight": normalise_group_weight(getattr(entry, "group_weight", None)),
        "probability": normalise_probability(getattr(entry, "probability", None)),
        "priority": entry.priority,
        "position": entry.position,
        "depth": normalise_depth(getattr(entry, "depth", None)),
        "role": normalise_role(getattr(entry, "role", None)),
        "enabled": bool(entry.enabled),
        "constant": bool(entry.constant),
        "vectorised": bool(getattr(entry, "vectorised", False)),
        "activation_kind": activation_kind_for(
            bool(entry.constant), bool(getattr(entry, "vectorised", False))
        ),
        "case_sensitive": bool(entry.case_sensitive),
        "whole_word": bool(entry.whole_word),
        "sticky_prompts": int(entry.sticky_prompts),
        "cooldown_prompts": int(entry.cooldown_prompts),
        "delay_prompts": int(entry.delay_prompts),
        "created_at": entry.created_at.isoformat(),
        "updated_at": entry.updated_at.isoformat() if entry.updated_at else None,
    }


async def _get_owned_book(session: AsyncSession, user_id: str, book_id: str) -> Lorebook | None:
    result = await session.execute(
        select(Lorebook).where(Lorebook.id == book_id, Lorebook.user_id == user_id)
    )
    return result.scalar_one_or_none()


async def _get_owned_entry(
    session: AsyncSession, user_id: str, book_id: str, entry_id: str
) -> LoreEntry | None:
    if await _get_owned_book(session, user_id, book_id) is None:
        return None
    result = await session.execute(
        select(LoreEntry).where(LoreEntry.id == entry_id, LoreEntry.lorebook_id == book_id)
    )
    return result.scalar_one_or_none()


async def create_lorebook(
    session: AsyncSession,
    user_id: str,
    name: str,
    description: str = "",
    scan_depth: int = 4,
    token_budget: int | None = None,
    scan_mode: str = "depth",
    scan_external_context: bool = False,
) -> Lorebook:
    if not name:
        raise ValueError("lorebook name must not be empty")
    check_scan_depth(scan_depth)
    if token_budget is not None and token_budget < 1:
        raise ValueError("token_budget must be >= 1")
    book = Lorebook(
        user_id=user_id,
        name=name,
        description=description,
        scan_depth=scan_depth,
        token_budget=token_budget,
        scan_mode=check_scan_mode(scan_mode),
        scan_external_context=check_scan_external_context(scan_external_context),
    )
    session.add(book)
    await session.commit()
    return book


async def list_lorebooks(session: AsyncSession, user_id: str) -> list[tuple[Lorebook, int]]:
    result = await session.execute(
        select(Lorebook, func.count(LoreEntry.id))
        .outerjoin(LoreEntry, LoreEntry.lorebook_id == Lorebook.id)
        .where(Lorebook.user_id == user_id)
        .group_by(Lorebook.id)
        .order_by(Lorebook.created_at)
    )
    return [(book, count) for book, count in result.all()]


async def get_lorebook(session: AsyncSession, user_id: str, book_id: str) -> Lorebook | None:
    return await _get_owned_book(session, user_id, book_id)


async def update_lorebook(
    session: AsyncSession,
    user_id: str,
    book_id: str,
    name: str | None = None,
    description: str | None = None,
    scan_depth: int | None = None,
    token_budget: int | None = None,
    scan_mode: str | None = None,
    scan_external_context: bool | None = None,
) -> Lorebook | None:
    book = await _get_owned_book(session, user_id, book_id)
    if book is None:
        return None
    if name is not None:
        if not name:
            raise ValueError("lorebook name must not be empty")
        book.name = name
    if description is not None:
        book.description = description
    if scan_depth is not None:
        book.scan_depth = check_scan_depth(scan_depth)
    if token_budget is not None:
        if token_budget < 1:
            raise ValueError("token_budget must be >= 1")
        book.token_budget = token_budget
    if scan_mode is not None:
        book.scan_mode = check_scan_mode(scan_mode)
    if scan_external_context is not None:
        book.scan_external_context = check_scan_external_context(
            scan_external_context
        )
    await session.commit()
    return book


async def delete_lorebook(session: AsyncSession, user_id: str, book_id: str) -> bool:
    if await _get_owned_book(session, user_id, book_id) is None:
        return False
    # Entries go with the book (FK cascade).
    await session.execute(delete(Lorebook).where(Lorebook.id == book_id))
    await session.commit()
    return True


async def create_entry(
    session: AsyncSession,
    user_id: str,
    book_id: str,
    name: str = "",
    content: str = "",
    keys: list[str] | None = None,
    secondary_keys: list[str] | None = None,
    selective_logic: str = "and_any",
    inclusion_group: str = "",
    group_weight: int = 100,
    probability: int = 100,
    priority: int = 100,
    position: str = "before_char",
    depth: int | None = None,
    role: str = "system",
    enabled: bool = True,
    constant: bool = False,
    vectorised: bool = False,
    case_sensitive: bool = False,
    whole_word: bool = True,
    sticky_prompts: int = 0,
    cooldown_prompts: int = 0,
    delay_prompts: int = 0,
) -> LoreEntry:
    if await _get_owned_book(session, user_id, book_id) is None:
        raise KeyError(book_id)
    entry = LoreEntry(
        lorebook_id=book_id,
        user_id=user_id,
        name=name,
        content=content,
        keys_json=_encode_keys(keys),
        secondary_keys_json=_encode_keys(secondary_keys),
        selective_logic=check_selective_logic(selective_logic),
        inclusion_group=check_inclusion_group(inclusion_group),
        group_weight=check_group_weight(group_weight),
        probability=check_probability(probability),
        priority=priority,
        position=_check_position(position),
        depth=check_depth(depth),
        role=check_role(role),
        enabled=enabled,
        constant=constant,
        vectorised=bool(vectorised),
        case_sensitive=case_sensitive,
        whole_word=whole_word,
        sticky_prompts=_check_prompts("sticky_prompts", sticky_prompts),
        cooldown_prompts=_check_prompts("cooldown_prompts", cooldown_prompts),
        delay_prompts=_check_prompts("delay_prompts", delay_prompts),
    )
    session.add(entry)
    await session.commit()
    return entry


async def list_entries(session: AsyncSession, user_id: str, book_id: str) -> list[LoreEntry] | None:
    if await _get_owned_book(session, user_id, book_id) is None:
        return None
    result = await session.execute(
        select(LoreEntry)
        .where(LoreEntry.lorebook_id == book_id)
        .order_by(LoreEntry.priority.desc(), LoreEntry.created_at)
    )
    return list(result.scalars().all())


async def get_entry(
    session: AsyncSession, user_id: str, book_id: str, entry_id: str
) -> LoreEntry | None:
    return await _get_owned_entry(session, user_id, book_id, entry_id)


async def update_entry(
    session: AsyncSession,
    user_id: str,
    book_id: str,
    entry_id: str,
    **fields,
) -> LoreEntry | None:
    entry = await _get_owned_entry(session, user_id, book_id, entry_id)
    if entry is None:
        return None
    if "name" in fields:
        entry.name = fields["name"]
    if "content" in fields:
        entry.content = fields["content"]
    if "keys" in fields:
        entry.keys_json = _encode_keys(fields["keys"])
    if "secondary_keys" in fields:
        entry.secondary_keys_json = _encode_keys(fields["secondary_keys"])
    if "selective_logic" in fields:
        entry.selective_logic = check_selective_logic(fields["selective_logic"])
    if "inclusion_group" in fields:
        entry.inclusion_group = check_inclusion_group(fields["inclusion_group"])
    if "group_weight" in fields:
        entry.group_weight = check_group_weight(fields["group_weight"])
    if "probability" in fields:
        entry.probability = check_probability(fields["probability"])
    if "priority" in fields:
        entry.priority = int(fields["priority"])
    if "position" in fields:
        entry.position = _check_position(fields["position"])
    if "depth" in fields:
        entry.depth = check_depth(fields["depth"])
    if "role" in fields:
        entry.role = check_role(fields["role"])
    for flag in ("enabled", "constant", "vectorised", "case_sensitive", "whole_word"):
        if flag in fields:
            setattr(entry, flag, bool(fields[flag]))
    for knob in ("sticky_prompts", "cooldown_prompts", "delay_prompts"):
        if knob in fields:
            setattr(entry, knob, _check_prompts(knob, fields[knob]))
    entry.updated_at = _now()
    await session.commit()
    return entry


async def delete_entry(session: AsyncSession, user_id: str, book_id: str, entry_id: str) -> bool:
    if await _get_owned_entry(session, user_id, book_id, entry_id) is None:
        return False
    await session.execute(delete(LoreEntry).where(LoreEntry.id == entry_id))
    await session.commit()
    return True
