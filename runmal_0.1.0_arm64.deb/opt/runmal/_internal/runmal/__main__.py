"""Rúnmál command-line entrypoint."""

from __future__ import annotations

import argparse
import sys

from runmal import __version__

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8098


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="runmal",
        description="Rúnmál — sovereign AI chat app",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    sub = parser.add_subparsers(dest="command")
    serve = sub.add_parser("serve", help="Run the local API server")
    serve.add_argument(
        "--host",
        default=DEFAULT_HOST,
        help=f"Bind host (default: {DEFAULT_HOST})",
    )
    serve.add_argument(
        "--port",
        type=int,
        default=DEFAULT_PORT,
        help=f"Bind port (default: {DEFAULT_PORT})",
    )
    backup = sub.add_parser("backup", help="SQLite backup operations (S114)")
    bsub = backup.add_subparsers(dest="backup_command")
    bcreate = bsub.add_parser("create", help="Online-backup the live database")
    bcreate.add_argument(
        "--output",
        default=None,
        help="Destination path (default: data-dir backups/runmal-backup-<ts>.db)",
    )
    bverify = bsub.add_parser("verify", help="Integrity-check a backup file")
    bverify.add_argument("path", help="Backup file to verify")
    bstage = bsub.add_parser(
        "stage",
        help="Restore a backup to a staging path and verify it (live DB untouched)",
    )
    bstage.add_argument("backup", help="Backup file to restore")
    bstage.add_argument(
        "--staging",
        default=None,
        help="Staging destination (default: data-dir staging/restore-<ts>.db)",
    )
    bfull = bsub.add_parser(
        "full-create", help="Create a full backup bundle (database + assets, S802)"
    )
    bfull.add_argument(
        "--output",
        default=None,
        help="Destination bundle path (default: data-dir backups/runmal-full-backup-<ts>.zip)",
    )
    bstagefull = bsub.add_parser(
        "full-stage", help="Validate + stage a full backup bundle with a report"
    )
    bstagefull.add_argument("bundle", help="Full backup bundle (.zip)")
    bstagefull.add_argument(
        "--staging",
        default=None,
        help="Staging directory (default: data-dir staging/full-restore-<ts>)",
    )
    profiles = sub.add_parser("profiles", help="Backend profile operations")
    psub = profiles.add_subparsers(dest="profiles_command")
    pmig = psub.add_parser(
        "migrate-to-aesir",
        help="Migrate an Ollama/OpenRouter profile to Aesir (S704)",
    )
    pmig.add_argument("--profile-id", required=True, help="Source profile id")
    pmig.add_argument(
        "--user-id",
        default=None,
        help="Owner user id (default: the sole local user, if exactly one)",
    )
    pmig.add_argument("--name", default=None, help="Target profile name")
    pmig.add_argument(
        "--chat-model",
        default=None,
        help="Aesir chat model (required for OpenRouter sources)",
    )
    pmig.add_argument(
        "--embeddings",
        action="store_true",
        help="Also migrate embeddings to Aesir (requires --embedding-model)",
    )
    pmig.add_argument("--embedding-model", default=None, help="Aesir embedding model")
    pmig.add_argument("--base-url", default=None, help="Aesir server base URL for the new profile")
    pmig.add_argument(
        "--repoint-chats",
        action="store_true",
        help="Repoint chats from the source profile to the migrated one",
    )
    pmig.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the migration plan without creating anything",
    )
    archive = sub.add_parser("archive", help="Portable .runmal archive operations (S801)")
    asub = archive.add_subparsers(dest="archive_command")
    aexp = asub.add_parser("export", help="Export a portable .runmal archive")
    aexp.add_argument("--output", required=True, help="Destination .runmal path")
    aexp.add_argument(
        "--user-id",
        default=None,
        help="Owner user id (default: the sole local user, if exactly one)",
    )
    aval = asub.add_parser("validate", help="Validate a .runmal archive")
    aval.add_argument("path", help="Archive file to validate")
    aimp = asub.add_parser(
        "import", help="Import a .runmal archive into a fresh staging directory (S802)"
    )
    aimp.add_argument("path", help="Archive file to import")
    aimp.add_argument(
        "--staging-dir",
        default=None,
        help="Staging directory (default: data-dir staging/archive-import-<ts>)",
    )
    doctor = sub.add_parser("doctor", help="Diagnose the installation (S804)")
    doctor.add_argument("--json", action="store_true", help="Print the report as JSON")
    doctor.add_argument(
        "--port",
        type=int,
        default=8098,
        help="App server port to probe (default: 8098)",
    )
    cleanup = sub.add_parser(
        "cleanup",
        help="Scan for orphan/stale files and clean them, dry-run by default (F-04)",
    )
    cleanup.add_argument("--json", action="store_true", help="Print the report as JSON")
    cleanup.add_argument(
        "--apply",
        action="store_true",
        help="Actually remove the listed items (default: dry-run, nothing removed)",
    )
    cleanup.add_argument(
        "--category",
        action="append",
        default=None,
        dest="categories",
        help="Restrict to this category (repeatable)",
    )
    cleanup.add_argument(
        "--allow-high-risk",
        action="store_true",
        help="Also remove high-risk items (chats of deleted characters)",
    )
    cleanup.add_argument(
        "--stale-backup-days",
        type=int,
        default=30,
        help="Backups older than this many days are stale (default: 30)",
    )
    cleanup.add_argument(
        "--stale-staging-days",
        type=int,
        default=7,
        help="Staging entries older than this many days are stale (default: 7)",
    )
    release = sub.add_parser("release", help="Release artifacts + gates (S806)")
    rsub = release.add_subparsers(dest="release_command")
    rsbom = rsub.add_parser("sbom", help="Print/write the SBOM (CycloneDX JSON)")
    rsbom.add_argument("--out", default=None, help="Write to this file")
    rlic = rsub.add_parser("licenses", help="Print/write the license manifest")
    rlic.add_argument("--out", default=None, help="Write to this file")
    rsub.add_parser("gate", help="Run the license gate over the installed tree")
    rsub.add_parser("check", help="Dry-run release consistency check (S807)")
    rmatrix = rsub.add_parser(
        "matrix", help="Run the self-hosted platform matrix leg here (S805)"
    )
    rmatrix.add_argument("--out", default=None, help="Write the JSON evidence report here")
    library = sub.add_parser("library", help="Bulk library import operations (P-022)")
    lsub = library.add_subparsers(dest="library_command")
    limp = lsub.add_parser("import", help="Import a whole folder of cards + lorebooks as one act")
    limp.add_argument("folder", help="Folder of card / lorebook files to import")
    limp.add_argument(
        "--dry-run",
        action="store_true",
        help="Report what would be imported without importing anything",
    )
    limp.add_argument("--json", action="store_true", help="Print the report as JSON")
    limp.add_argument(
        "--user-id",
        default=None,
        help="Owner user id (default: the sole local user, if exactly one)",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "serve":
        import uvicorn

        from runmal.app import create_app, default_session_factory

        uvicorn.run(create_app(default_session_factory()), host=args.host, port=args.port)
    elif args.command == "backup":
        return _run_backup(args)
    elif args.command == "profiles":
        return _run_profiles(args)
    elif args.command == "archive":
        return _run_archive(args)
    elif args.command == "doctor":
        return _run_doctor(args)
    elif args.command == "cleanup":
        return _run_cleanup(args)
    elif args.command == "release":
        return _run_release(args)
    elif args.command == "library":
        return _run_library(args)
    return 0


def _run_backup(args: argparse.Namespace) -> int:
    import json

    from runmal.backups import service

    try:
        if args.backup_command == "create":
            info = service.backup_database(dest=args.output)
        elif args.backup_command == "verify":
            info = service.verify_backup(args.path)
        elif args.backup_command == "stage":
            info = service.stage_restore(args.backup, staging_path=args.staging)
        elif args.backup_command == "full-create":
            from runmal.backups import full

            full_info = full.create_full_backup(dest=args.output)
            print(json.dumps(full_info.to_dict(), indent=2))
            return 0
        elif args.backup_command == "full-stage":
            from runmal.backups import full

            report = full.stage_full_restore(args.bundle, staging_root=args.staging)
            print(json.dumps(report.to_dict(), indent=2))
            return 0
        else:
            print(
                "usage: runmal backup {create|verify|stage|full-create|full-stage} ...",
                file=sys.stderr,
            )
            return 2
    except service.BackupError as exc:
        print(f"backup failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(info.to_dict(), indent=2))
    return 0


def _run_profiles(args: argparse.Namespace) -> int:
    import asyncio
    import json

    if args.profiles_command != "migrate-to-aesir":
        print("usage: runmal profiles migrate-to-aesir ...", file=sys.stderr)
        return 2

    async def _go() -> dict:
        from sqlalchemy import select

        from runmal.app import default_session_factory
        from runmal.backends import profile_migration
        from runmal.backends.profiles import get_profile, profile_to_dict
        from runmal.db.models import User

        factory = default_session_factory()
        async with factory() as session:
            user_id = args.user_id
            if user_id is None:
                users = list(await session.scalars(select(User)))
                if len(users) != 1:
                    raise ValueError(
                        "--user-id is required unless exactly one local "
                        f"user exists (found {len(users)})"
                    )
                user_id = users[0].id
            source = await get_profile(session, user_id, args.profile_id)
            if source is None:
                raise ValueError(f"profile not found: {args.profile_id}")
            plan_kwargs = {
                "target_name": args.name,
                "aesir_chat_model": args.chat_model,
                "migrate_embeddings": args.embeddings,
                "aesir_embedding_model": args.embedding_model,
                "base_url": args.base_url,
            }
            if args.dry_run:
                plan = profile_migration.plan_profile_migration(source, **plan_kwargs)
                return {"dry_run": True, "plan": plan.to_dict()}
            result = await profile_migration.apply_profile_migration(
                session,
                user_id,
                args.profile_id,
                repoint_chats=args.repoint_chats,
                **plan_kwargs,
            )
            return {
                "dry_run": False,
                "profile": profile_to_dict(result.profile),
                "plan": result.plan.to_dict(),
                "repointed_chats": result.repointed_chats,
            }

    try:
        out = asyncio.run(_go())
    except ValueError as exc:
        print(f"profile migration failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(out, indent=2))
    return 0


def _run_archive(args: argparse.Namespace) -> int:
    import asyncio
    import json

    from runmal.portable.archive import ArchiveError

    if args.archive_command == "validate":
        from runmal.portable.archive import validate_archive

        try:
            manifest = validate_archive(args.path)
        except ArchiveError as exc:
            print(f"archive invalid: {exc}", file=sys.stderr)
            return 1
        print(json.dumps({"valid": True, "manifest": manifest}, indent=2))
        return 0
    if args.archive_command == "import":
        import asyncio as _asyncio

        from runmal.portable.restore import import_archive

        async def _import() -> dict:
            if args.staging_dir:
                root = args.staging_dir
            else:
                from datetime import UTC, datetime

                from runmal.auth import data_dir

                root = str(
                    data_dir()
                    / "staging"
                    / f"archive-import-{datetime.now(UTC).strftime('%Y%m%dT%H%M%S')}"
                )
            report = await import_archive(args.path, root)
            return report.to_dict()

        try:
            out = _asyncio.run(_import())
        except ArchiveError as exc:
            print(f"archive import failed: {exc}", file=sys.stderr)
            return 1
        print(json.dumps(out, indent=2))
        return 0
    if args.archive_command != "export":
        print("usage: runmal archive {export|validate} ...", file=sys.stderr)
        return 2

    async def _go() -> dict:
        from sqlalchemy import select

        from runmal.app import default_session_factory
        from runmal.db.models import User
        from runmal.portable.archive import export_archive

        factory = default_session_factory()
        async with factory() as session:
            user_id = args.user_id
            if user_id is None:
                users = list(await session.scalars(select(User)))
                if len(users) != 1:
                    raise ValueError(
                        "--user-id is required unless exactly one local "
                        f"user exists (found {len(users)})"
                    )
                user_id = users[0].id
            info = await export_archive(session, user_id, args.output)
            return info.to_dict()

    try:
        out = asyncio.run(_go())
    except ValueError as exc:
        print(f"archive export failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(out, indent=2))
    return 0


def _run_release(args: argparse.Namespace) -> int:
    import json
    from pathlib import Path

    from runmal.release.sbom import (
        build_license_manifest,
        build_sbom,
        gate_report,
    )

    if args.release_command == "gate":
        report = gate_report()
        print(report.summary())
        return 0 if report.passed else 1
    if args.release_command == "check":
        from runmal.release.versioning import check_release_consistency

        result = check_release_consistency()
        print(result.summary())
        return 0 if result.ok else 1
    if args.release_command == "matrix":
        from runmal.release.matrix import run_platform_matrix

        report = run_platform_matrix()
        text = json.dumps(report.to_dict(), indent=2, sort_keys=True)
        if args.out:
            Path(args.out).write_text(text + "\n", encoding="utf-8")
            print(f"wrote {args.out}")
        print(report.summary())
        return 0 if report.passed else 1
    if args.release_command == "sbom":
        payload = build_sbom()
    elif args.release_command == "licenses":
        payload = build_license_manifest()
    else:
        print("usage: runmal release {sbom|licenses|gate|check|matrix}", file=sys.stderr)
        return 2
    text = json.dumps(payload, indent=2, sort_keys=True)
    if args.out:
        Path(args.out).write_text(text + "\n", encoding="utf-8")
        print(f"wrote {args.out}")
    else:
        print(text)
    return 0


def _run_cleanup(args: argparse.Namespace) -> int:
    import json

    from runmal.diagnostics.cleanup import CATEGORY_RISK, clean_cleanup, scan_cleanup

    categories = set(args.categories) if args.categories else None
    if categories is not None:
        unknown = categories - set(CATEGORY_RISK)
        if unknown:
            print(
                f"cleanup: unknown categories: {', '.join(sorted(unknown))} "
                f"(known: {', '.join(sorted(CATEGORY_RISK))})",
                file=sys.stderr,
            )
            return 2
    report = scan_cleanup(
        stale_backup_days=args.stale_backup_days,
        stale_staging_days=args.stale_staging_days,
    )
    result = clean_cleanup(
        report,
        categories=categories,
        apply=args.apply,
        allow_high_risk=args.allow_high_risk,
    )
    if args.json:
        print(
            json.dumps(
                {"scan": report.to_dict(), "result": result.to_dict()},
                indent=2,
            )
        )
        return 0
    print(f"runmal cleanup — data dir {report.base_dir}")
    for item in report.items:
        print(f"[{item.risk}] {item.category}: {item.detail}")
        if item.path:
            print(f"       path: {item.path} ({item.size_bytes} bytes)")
        print(f"       risk: {item.warning}")
    for skipped in report.skipped:
        print(f"[skip] {skipped['category']}: {skipped['reason']}")
    if result.dry_run:
        print(
            f"dry run: {len(result.planned)} item(s) would be removed, "
            f"{len(result.skipped)} skipped — nothing was deleted; "
            "pass --apply to remove the planned items"
        )
    else:
        print(
            f"removed {len(result.removed)} item(s), "
            f"{result.bytes_reclaimed} bytes reclaimed, "
            f"{len(result.skipped)} skipped"
        )
        for skipped in result.skipped:
            print(f"[not removed] {skipped['category']}: {skipped['reason']}")
    return 0


def _report_total(report, payload: dict, name: str) -> int:
    """Read one report total under either spelling: the task contract's
    ``total_refused`` attribute style or the report's ``totals`` dict
    style (``{total_seen, accepted, repaired, refused, skipped}``)."""
    candidates = [name, name.removeprefix("total_")]
    value = getattr(report, name, None)
    if isinstance(value, int):
        return value
    containers = [payload]
    report_totals = getattr(report, "totals", None)
    if isinstance(report_totals, dict):
        containers.append(report_totals)
    if isinstance(payload, dict) and isinstance(payload.get("totals"), dict):
        containers.append(payload["totals"])
    for container in containers:
        if isinstance(container, dict):
            for key in candidates:
                if isinstance(container.get(key), int):
                    return container[key]
    return 0


def _entry_field(entry, *names, default=None):
    if isinstance(entry, dict):
        for name in names:
            value = entry.get(name)
            if value is not None:
                return value
        return default
    for name in names:
        value = getattr(entry, name, None)
        if value is not None:
            return value
    return default


def _repair_text(repair) -> str:
    """One repair note as text: its detail if it has one, else its code."""
    if isinstance(repair, dict):
        return str(repair.get("detail") or repair.get("code") or "")
    if isinstance(repair, str):
        return repair
    return str(getattr(repair, "detail", "") or getattr(repair, "code", "") or repair)


_PATH_KEYS = ("relpath", "path", "source", "filename", "file", "relative_path")
_NAME_KEYS = ("created_name", "name", "character_name", "title", "imported_name")


def _library_report_rows(report, payload: dict) -> list[tuple[str, str, str]]:
    """Normalise a bulk report's per-file entries to (status, path, detail),
    including the report's separate skipped list."""
    raw = None
    for attr in ("entries", "outcomes", "results", "items", "files"):
        value = getattr(report, attr, None)
        if isinstance(value, list) and value:
            raw = value
            break
    if raw is None and isinstance(payload, dict):
        for key in ("entries", "outcomes", "results", "items", "files"):
            value = payload.get(key)
            if isinstance(value, list):
                raw = value
                break
    rows = []
    seen_paths = set()
    for entry in raw or []:
        status = _entry_field(entry, "outcome", "status", "kind", "result", default="unknown")
        if hasattr(status, "value"):
            status = status.value
        status = str(status).lower()
        path = _entry_field(entry, *_PATH_KEYS, default="")
        name = _entry_field(entry, *_NAME_KEYS)
        repairs = _entry_field(entry, "repairs", "repair", "fixes", "applied_repairs")
        reason = _entry_field(entry, "reason", "detail", "message", "error")
        if isinstance(repairs, (list, tuple)):
            repairs_text = "; ".join(t for t in (_repair_text(r) for r in repairs) if t)
        elif repairs is not None:
            repairs_text = _repair_text(repairs)
        else:
            repairs_text = ""
        if status == "accepted":
            detail = name or reason or "imported"
        elif status == "repaired":
            detail = repairs_text or name or reason or "repaired"
        else:
            detail = reason or repairs_text or status
        rows.append((status, str(path), str(detail)))
        seen_paths.add(str(path))
    skipped_raw = getattr(report, "skipped", None)
    if not isinstance(skipped_raw, list) and isinstance(payload, dict):
        skipped_raw = payload.get("skipped")
    for entry in skipped_raw or []:
        path = str(_entry_field(entry, *_PATH_KEYS, default=""))
        if path in seen_paths:
            continue
        reason = _entry_field(entry, "reason", "detail", "message", "error")
        rows.append(("skipped", path, str(reason or "skipped")))
        seen_paths.add(path)
    return rows


def _print_library_report(report, folder: str, *, dry_run: bool) -> None:
    try:
        payload = report.to_dict()
    except Exception:
        payload = {}
    if not isinstance(payload, dict):
        payload = {}
    seen = _report_total(report, payload, "total_seen")
    accepted = _report_total(report, payload, "total_accepted")
    repaired = _report_total(report, payload, "total_repaired")
    refused = _report_total(report, payload, "total_refused")
    skipped = _report_total(report, payload, "total_skipped")
    header = f"runmal library import — {folder}"
    if dry_run:
        header += " (dry run)"
    print(header)
    for status, path, detail in _library_report_rows(report, payload):
        print(f"[{status}] {path} — {detail}")
    print(
        f"summary: {seen} seen, {accepted} accepted, {repaired} repaired, "
        f"{refused} refused, {skipped} skipped"
    )


def _run_library(args: argparse.Namespace) -> int:
    import asyncio
    import json
    from pathlib import Path

    if args.library_command != "import":
        print(
            "usage: runmal library import <folder> [--dry-run] [--json] [--user-id ID]",
            file=sys.stderr,
        )
        return 2
    root = Path(args.folder)
    if not root.exists():
        print(f"library import failed: folder not found: {args.folder}", file=sys.stderr)
        return 2
    if not root.is_dir():
        print(f"library import failed: not a directory: {args.folder}", file=sys.stderr)
        return 2

    async def _go():
        from sqlalchemy import select

        from runmal.app import default_session_factory
        from runmal.db.models import User
        from runmal.library import import_library_folder

        factory = default_session_factory()
        async with factory() as session:
            user_id = args.user_id
            if user_id is None:
                users = list(await session.scalars(select(User)))
                if len(users) != 1:
                    raise ValueError(
                        "--user-id is required unless exactly one local "
                        f"user exists (found {len(users)})"
                    )
                user_id = users[0].id
            return await import_library_folder(
                session, user_id, root, dry_run=args.dry_run, recursive=True
            )

    try:
        report = asyncio.run(_go())
    except Exception as exc:
        # The act could not run at all (e.g. database unavailable or no
        # resolvable owner): no report exists, so this is exit 2, not 1.
        print(f"library import failed: {exc}", file=sys.stderr)
        return 2
    try:
        payload = report.to_dict()
    except Exception:
        payload = {}
    if not isinstance(payload, dict):
        payload = {}
    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        _print_library_report(report, args.folder, dry_run=args.dry_run)
    return 0 if _report_total(report, payload, "total_refused") == 0 else 1


def _run_doctor(args: argparse.Namespace) -> int:
    import json

    from runmal.diagnostics.doctor import FAIL, OK, WARN, run_doctor

    report = run_doctor(port=args.port)
    if args.json:
        print(json.dumps(report.to_dict(), indent=2))
    else:
        print(f"runmal doctor — app {report.app_version}, db {report.db_path}")
        icons = {OK: "ok  ", WARN: "warn", FAIL: "FAIL"}
        for finding in report.findings:
            print(f"[{icons[finding.status]}] {finding.check}: {finding.detail}")
            if finding.action and finding.status != OK:
                print(f"       -> {finding.action}")
        print("overall:", "OK" if report.ok else "PROBLEMS FOUND")
    return 0 if report.ok else 1


if __name__ == "__main__":
    sys.exit(main())
