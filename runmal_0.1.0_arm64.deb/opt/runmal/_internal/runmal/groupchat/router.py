"""Group chat API (S305): stateless turn endpoint with SSE streaming.

The client holds the roster + transcript; each turn posts them with the
new user text and a strategy. The server rebuilds the S210 GroupChat,
and streams per-participant events: ``typing`` -> ``token``* ->
``message`` per speaker, then ``turn_end`` (with the round-robin cursor
to carry into the next turn). Generation runs through the S108 service
(fake backend today; real backends slot in behind the same seam).
"""

from __future__ import annotations

import json

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from runmal.cards import import_card
from runmal.characters import service as characters
from runmal.db.deps import get_owner_id, get_session
from runmal.generation import service as generation
from runmal.groupchat import store
from runmal.groupchat.core import GroupChat, GroupMessage, Participant, Strategy

router = APIRouter(tags=["group"])


class HistoryIn(BaseModel):
    author: str
    content: str


class TurnIn(BaseModel):
    participant_ids: list[str]
    history: list[HistoryIn] = []
    user_text: str
    strategy: str = "mention"
    rr_cursor: int = 0


async def _load_participants(
    session: AsyncSession, user_id: str, ids: list[str]
) -> list[Participant]:
    participants: list[Participant] = []
    for cid in ids:
        character = await characters.get_character(session, user_id, cid)
        if character is None:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"unknown participant: {cid}",
            )
        card = import_card(character.card_json.encode(), "card.json")
        persona = card.personality or card.description
        participants.append(
            Participant(character_id=character.id, name=character.name, persona=persona)
        )
    return participants


@router.post("/group/turn")
async def group_turn(
    body: TurnIn,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    try:
        strategy = Strategy(body.strategy)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"unknown strategy: {body.strategy!r}",
        ) from exc
    participants = await _load_participants(session, user_id, body.participant_ids)
    chat = GroupChat(
        participants=participants,
        history=[GroupMessage(h.author, h.content) for h in body.history],
    )
    chat.cursor = body.rr_cursor
    chat.post_user(body.user_text)

    async def sse():
        for speaker in chat.speakers_for(strategy):
            yield _event({"type": "typing", "author": speaker.name})
            prompt = chat.build_prompt(speaker)
            prompt_text = "\n".join(m["content"] for m in prompt)
            text = ""
            request_id = generation.new_request_id()
            async for event in generation.generate_events(
                    request_id, prompt_text, plugin_events=False):
                if event.get("type") == "token":
                    text += event["text"]
                    yield _event({"type": "token", "author": speaker.name, "text": event["text"]})
                elif event.get("type") == "reasoning":
                    yield _event({"type": "reasoning", "author": speaker.name,
                                  "text": event["text"]})
            chat.history.append(GroupMessage(speaker.name, text))
            chat.note_spoke(strategy, speaker)
            yield _event({"type": "message", "author": speaker.name, "content": text})
        yield _event({"type": "turn_end", "rr_cursor": chat.cursor})

    return StreamingResponse(sse(), media_type="text/event-stream")


def _event(payload: dict) -> str:
    return f"data: {json.dumps(payload)}\n\n"


# -- Persistent rooms (roadmap S210): room / members / transcript --------


class GroupCreate(BaseModel):
    name: str = ""
    member_character_ids: list[str] = []


class GroupUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1)
    speaker_policy: str | None = None
    speaker_config: dict | None = None


class MemberAdd(BaseModel):
    character_id: str


class MemberSettings(BaseModel):
    talkativeness: float | None = None
    muted: bool | None = None


class GroupMessageIn(BaseModel):
    speaker: str  # "user" or a member character's id
    content: str


def _unprocessable(exc: ValueError) -> HTTPException:
    return HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc))


@router.post("/groups", status_code=status.HTTP_201_CREATED)
async def create_group(
    body: GroupCreate,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    try:
        group = await store.create_group(session, user_id, body.name, body.member_character_ids)
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    return await store.describe_group(session, user_id, group.id)


@router.get("/groups")
async def list_groups(
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    return await store.list_groups(session, user_id)


@router.get("/groups/{group_id}")
async def get_group(
    group_id: str,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    payload = await store.describe_group(session, user_id, group_id)
    if payload is None:
        raise HTTPException(status_code=404, detail="group not found")
    return payload


@router.patch("/groups/{group_id}")
async def update_group(
    group_id: str,
    body: GroupUpdate,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    try:
        payload = await store.update_group(
            session,
            user_id,
            group_id,
            name=body.name,
            speaker_policy=body.speaker_policy,
            speaker_config=body.speaker_config,
        )
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    if payload is None:
        raise HTTPException(status_code=404, detail="group not found")
    return payload


@router.delete("/groups/{group_id}")
async def delete_group(
    group_id: str,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    if not await store.delete_group(session, user_id, group_id):
        raise HTTPException(status_code=404, detail="group not found")
    return {"deleted": True, "id": group_id}


@router.post("/groups/{group_id}/members", status_code=status.HTTP_201_CREATED)
async def add_member(
    group_id: str,
    body: MemberAdd,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    try:
        member = await store.add_member(session, user_id, group_id, body.character_id)
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    if member is None:
        raise HTTPException(status_code=404, detail="group not found")
    return member


@router.delete("/groups/{group_id}/members/{character_id}")
async def remove_member(
    group_id: str,
    character_id: str,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    if not await store.remove_member(session, user_id, group_id, character_id):
        raise HTTPException(status_code=404, detail="member not found")
    return {"deleted": True, "id": character_id}


@router.patch("/groups/{group_id}/members/{character_id}")
async def update_member_settings(
    group_id: str,
    character_id: str,
    body: MemberSettings,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    try:
        member = await store.update_member_settings(
            session,
            user_id,
            group_id,
            character_id,
            talkativeness=body.talkativeness,
            muted=body.muted,
        )
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    if member is None:
        raise HTTPException(status_code=404, detail="member not found")
    return member


@router.post("/groups/{group_id}/messages", status_code=status.HTTP_201_CREATED)
async def post_group_message(
    group_id: str,
    body: GroupMessageIn,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    try:
        message = await store.append_message(session, user_id, group_id, body.speaker, body.content)
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    if message is None:
        raise HTTPException(status_code=404, detail="group not found")
    return store.message_to_dict(message)


@router.get("/groups/{group_id}/messages")
async def get_group_messages(
    group_id: str,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    messages = await store.list_messages(session, user_id, group_id)
    if messages is None:
        raise HTTPException(status_code=404, detail="group not found")
    return [store.message_to_dict(m) for m in messages]


# -- Group deepening (roadmap P-070): activation on the room road,
# per-member overrides, group lore/persona handling -------------------


class NextIn(BaseModel):
    user_text: str | None = None
    manual_speaker_id: str | None = None
    generate: bool = False


class RunIn(BaseModel):
    turns: int = 1
    generate: bool = False


@router.get("/groups/{group_id}/deepening")
async def get_group_deepening(
    group_id: str,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    from runmal.groupchat import deepening

    payload = await deepening.get_deepening(session, user_id, group_id)
    if payload is None:
        raise HTTPException(status_code=404, detail="group not found")
    return payload


@router.put("/groups/{group_id}/deepening")
async def put_group_deepening(
    group_id: str,
    payload: dict,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    from runmal.groupchat import deepening

    try:
        result = await deepening.put_deepening(session, user_id, group_id, payload)
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    if result is None:
        raise HTTPException(status_code=404, detail="group not found")
    return result


@router.get("/groups/{group_id}/members/{character_id}/peek")
async def peek_group_member(
    group_id: str,
    character_id: str,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    from runmal.groupchat import deepening

    payload = await deepening.member_peek(session, user_id, group_id, character_id)
    if payload is None:
        raise HTTPException(status_code=404, detail="member not found")
    return payload


@router.patch("/groups/{group_id}/members/{character_id}/override")
async def patch_group_member_override(
    group_id: str,
    character_id: str,
    payload: dict,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    from runmal.groupchat import deepening

    try:
        result = await deepening.patch_member_override(
            session, user_id, group_id, character_id, payload
        )
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    if result is None:
        raise HTTPException(status_code=404, detail="member not found")
    return result


@router.post("/groups/{group_id}/next")
async def group_next(
    group_id: str,
    body: NextIn,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    from runmal.groupchat import deepening

    try:
        result = await deepening.next_turn(
            session,
            user_id,
            group_id,
            user_text=body.user_text,
            manual_speaker_id=body.manual_speaker_id,
            generate=body.generate,
        )
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    except deepening.GenerationFailedError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    if result is None:
        raise HTTPException(status_code=404, detail="group not found")
    return result


@router.post("/groups/{group_id}/run")
async def group_run(
    group_id: str,
    body: RunIn,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    from runmal.groupchat import deepening

    try:
        result = await deepening.run_turns(
            session, user_id, group_id, turns=body.turns, generate=body.generate
        )
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    except deepening.GenerationFailedError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    if result is None:
        raise HTTPException(status_code=404, detail="group not found")
    return result


# -- Absent-character presence + history digest (P-071) -------------------
# Appended at end of file by design: P-070 works the member routes
# above; this block adds new surface only and touches no existing
# handler. Presence state + digest semantics live in
# runmal.groupchat.presence (metadata-only events, no migration).

from fastapi import Query

from runmal.groupchat import presence


class ReturnIn(BaseModel):
    max_entries: int = Field(default=presence.DEFAULT_MAX_ENTRIES, ge=1, le=500)
    excerpt_chars: int = Field(default=presence.DEFAULT_EXCERPT_CHARS, ge=20, le=5000)


@router.post("/groups/{group_id}/members/{character_id}/leave")
async def mark_member_absent(
    group_id: str,
    character_id: str,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    try:
        record = await presence.mark_absent(session, user_id, group_id, character_id)
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    if record is None:
        raise HTTPException(status_code=404, detail="group not found")
    return record


@router.post("/groups/{group_id}/members/{character_id}/return")
async def return_member(
    group_id: str,
    character_id: str,
    body: ReturnIn | None = None,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    caps = body if body is not None else ReturnIn()
    try:
        digest = await presence.mark_returned(
            session,
            user_id,
            group_id,
            character_id,
            max_entries=caps.max_entries,
            excerpt_chars=caps.excerpt_chars,
        )
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    if digest is None:
        raise HTTPException(status_code=404, detail="group not found")
    return digest


@router.get("/groups/{group_id}/members/{character_id}/digest")
async def preview_member_digest(
    group_id: str,
    character_id: str,
    max_entries: int = Query(default=presence.DEFAULT_MAX_ENTRIES, ge=1, le=500),
    excerpt_chars: int = Query(default=presence.DEFAULT_EXCERPT_CHARS, ge=20, le=5000),
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    try:
        digest = await presence.missed_digest(
            session,
            user_id,
            group_id,
            character_id,
            max_entries=max_entries,
            excerpt_chars=excerpt_chars,
        )
    except ValueError as exc:
        raise _unprocessable(exc) from exc
    if digest is None:
        raise HTTPException(status_code=404, detail="group not found")
    return digest


@router.get("/groups/{group_id}/presence")
async def get_group_presence(
    group_id: str,
    user_id: str = Depends(get_owner_id),
    session: AsyncSession = Depends(get_session),
):
    records = await presence.list_presence(session, user_id, group_id)
    if records is None:
        raise HTTPException(status_code=404, detail="group not found")
    return records
